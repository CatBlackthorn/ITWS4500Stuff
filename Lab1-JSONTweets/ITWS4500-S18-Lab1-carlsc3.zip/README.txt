README

Using Bootstrap made it much easier as I simply assigned 5 tweets to a 'slide' within
a carousel. This allowed Bootstrap to deal with the transitions between the slides and
the rest of the carousel data.
Bootstrap also kept the page relatively clean, although I wouldn't access the site on a
small viewport because it looks very weird and elongated.

Pictures were a veritable pain because no matter how many times I 'tested' the connection
to that picture, it would toss a 404 error in the console and that naturally drove me
absolutely crazy. So, nobody got their pictures!!! HAHAHA!

Hashtags are technically included, they just attatch themselves to the end of the tweets