README
carlsc3

Wow...this lab. So, I started using the ntwitter app and then I had problems with
its deprecated authorization form...or I was just silly. So, then I tried using
twitter-node-client and twitter-js-client. These were both very helpful but again
the authorization alluded me again, Then!!! I found the github: Twitter Application
Only Authentication Demo. IT WAS THE MOST HELPFUL THING EVER TO ACTUALLY FIND AUTH.
Then I could build the rest of the server.

The front end was all done for lab4 though, so that was nice. Even if I couldn't use
it in lab4. Angular is something I enjoy. The file saves were simple once I figured
out the one command and assured it would warn when the file wasn't savec.