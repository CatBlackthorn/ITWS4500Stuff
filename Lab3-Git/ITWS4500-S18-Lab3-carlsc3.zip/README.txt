
Chelsea Carlson
Lab3
README
carlsc3

Part 1:
I installed TaskCoach as a small local only bug tracking software, it's something I heard
was good for small projects and I wanted to actually test it and see how it is for my own
work on this group project and a few side projects.
A screenshot is included as LocalTracking.png

Github:
https://github.com/CatBlackthorn

Local Git for project:
See git.png

Part 2:
Project: Vercipe
Recipe Tracking Software.
This is an online service to host your recipes, you input the recipes and you can make
changes to those recipes. Any changes will be saved and you can then see a version
history for that recipe.

Server:
Yuze set up a server complete with some nice bug tracking software
Server IP:
52.168.122.20

Server Bug Tracking:
http://52.168.122.20/src/mantisbt
PNG included BugtrackingSoftware.png

Group Git:
https://github.com/bobmayuze/Vercipe