
README
carlsc3
Lab 8

So, I added a landing page with instructions, I tried to keep it brief because not everyone enjoys reading instructions.

I liked my original set-up and my friend who tested it thought it was reasonably simple to use. I did alter the date print outs, because the original was not so pretty. But I like it more now.
The page is still blue because blue is pretty cool.

Included is the package.json as always so a quick npm install is all you need to run the files.

XML is still not fixed. I don't understand why it refuses to be nice and play along.