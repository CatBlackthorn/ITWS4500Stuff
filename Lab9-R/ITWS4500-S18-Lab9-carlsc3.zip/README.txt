
README
carlsc3

Dataset:
I went to kaggle,com and downloaded a set of data about pizza. Becuase I wanted to
see what types of pizza was available where. I didn't expect this dataset to be this 
massive. So, I chose a couple of pizza options and went to where they matched.

Learned:
I learned there are some really weird types of pizza and the number of places serving
these pizzas is suprising! A few of the graphs that didn't make it out were super cool
but totally unreadable and the few things that you could read were super connected.
I didn't include it because it wouldn't show up well.

Challenges:
So many. This is a massive dataset so a couple bits of data were just shaved off altogether.
I couldn't map the entire thing like I wanted because there were too many points of data.
But the designs where all of the cities and the pizzas were vertices as just cool (I decided to
include that one just because dang). R was a challenge to learn because I had no idea how to add
to lists or vectors and the initial input for read.csv made things as factors rather than the
strings that I wanted them to be. That perplexed me for a good several hours.
I asked Andrew Leaf for help to create an edgelist, he was really elpful. Reddit was also my
friend in learning how to deal with errors. http://www.r-tutor.com/r-introduction/vector was 
another good source for simple object questions.

It's not creative, I'll admit that, but I had fun just making chaos happen and reading some of
the weird pizza options.