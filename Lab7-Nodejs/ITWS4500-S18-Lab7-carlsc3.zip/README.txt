
README
carlsc3
Lab 7

This was interesting, the hard thing I ran into was the xml, adding all of the mongoDB was
reasonably simple. So, the XML is error-prone and probably not going to work... I can't
figure out why. Probably because it takes too long to actually go through and save the file?

I did fix the CSV saving problem though, silly error.