README
carlsc3

Q1: It would be better to save it on the server because odds are if it is a big file, the server will have more available ram and memory to handle the requests. Otherwise you are putting strain on the client computer to reformat entire files.

Okay: This time I've included the package.json!

Finally made express and angular be happy together. Now you can simply access localhost:3000 and it will work...Fingers crossed

Enjoyed this lab.
