README
carlsc3

I decided to model this lab as the start of lab 5 and use the twitter API
The hardest thing I've come across is the Twitter API Oauth stuff for an
application. Which meant I had to stop for that because it through the CORS
error because Twitter doesn't support it.

At this point I moved the code for the Twitter front end to Lab5. Then went
back to modeling the weatherAPI with angular. I did however add a zipcode
search box for the weather though, to enable you to search more than just Troy NY,