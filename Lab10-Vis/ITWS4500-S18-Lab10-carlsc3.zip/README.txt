
README
carlsc3
Lab 10

Used chartjs...never again. So many problems, horrible documentation for specifics.

Okay, so I started with one plan then ended with another. What this graph contains is a scatterplot of datapoints that state how many words are used during what time of day.

I figured the word count would go down as it got later but in some of my testing I realized it doesnt. It gets higher.

I really wanted to do a line chart but I wanted too much data in it. The other option was a bubble chart but I didnt have a third variable I wanted to compare.

The last graph is unfinished, sorry.